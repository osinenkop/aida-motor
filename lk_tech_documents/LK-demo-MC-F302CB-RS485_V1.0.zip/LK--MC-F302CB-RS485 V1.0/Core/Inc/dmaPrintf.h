#ifndef __DMA_PRINTF_H__
#define __DMA_PRINTF_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "usart.h"
#include "stdarg.h"
#include "stdio.h"


void Uart3DmaPrintf(const char *format,...);


#ifdef __cplusplus
}
#endif
#endif /* __DMA_PRINTF_H__ */





#include "dmaPrintf.h"


void Uart3DmaPrintf(const char *format,...)
{
	uint16_t len;
	va_list args;	
	va_start(args,format);
	len = vsnprintf((char*)uart3TxBuffer,sizeof(uart3TxBuffer),(char*)format,args);
	va_end(args);
	HAL_UART_Transmit_DMA(&huart3, uart3TxBuffer, len);
}


